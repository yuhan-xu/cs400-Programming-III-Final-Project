README

Course: cs400
Semester: Fall 2019
Project name: Social Network
Team Members:
1. Yuhan Xu, lecture002, and yxu329@wisc.edu
2. Zhuoxuan Li, lecture001, and zli844@wisc.edu
3. Sheriff M. Issaka, lecture001, and issaka@wisc.edu
4. Minglei Ju, lecture001, and mju7@wisc.edu

 

Which team members were on same xteam together?
No

Other notes or comments to the grader: For this assignment, firstly enter your name in the first pop-up window in the program. Then, in the second pop-up window, there are two buttons "A" (import and read from a file)and "B" (enter friends manually). For a2, we only implement button "B", so when you test our program please click button B. And then you can add two friends' names in the top panel, click "Add" at the bottom, and a graph will show up (with two friend nodes and an edge connecting them). 

[place any comments or notes that will help the grader here]