package application;
//package a2;

public class Person {
	public Person() {
		this.name = name;
	}
	public Person(String name) {
		this.name = name;
	}
	public String name;
	
	public String getName() {
		return this.name;
	}
}
