package application;

public class IllegalNameException extends Exception {

}
