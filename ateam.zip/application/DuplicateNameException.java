package application;

public class DuplicateNameException extends Exception {

}
